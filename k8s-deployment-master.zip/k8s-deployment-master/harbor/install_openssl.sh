#!bin/bash
yum install openssl
yum install openssl-devel