#!/usr/bin/env bash
sudo yum install -y git
 git --version